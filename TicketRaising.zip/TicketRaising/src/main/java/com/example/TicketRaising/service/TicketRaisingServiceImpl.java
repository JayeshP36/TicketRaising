package com.example.TicketRaising.service;

import com.example.TicketRaising.dao.TicketRaisingDao;
import com.example.TicketRaising.model.Tickets;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class TicketRaisingServiceImpl implements TicketRaisingService{

    @Autowired
    TicketRaisingDao ticketRaisingDao;
    @Override
    public List<Tickets> getAllTickets() {
        return ticketRaisingDao.findAll();
    }

    @Override
    public Tickets findTicketsById(int id) {
        return ticketRaisingDao.findById(id).orElse(null);
    }

    @Override
    public void saveTickets(Tickets t) {
        ticketRaisingDao.save(t);
    }

    @Override
    public void deleteTickets(Tickets t) {
        ticketRaisingDao.delete(t);
    }

    @Override
    public List<Tickets> getAllTicketsByQuery(String query) {
        return ticketRaisingDao.findByQuery(query);
    }
}
